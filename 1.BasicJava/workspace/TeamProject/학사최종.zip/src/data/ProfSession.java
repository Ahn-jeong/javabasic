package data;

import vo.ProfessorVO;

public class ProfSession {//로그인되어있는 교수 정보 저장
	public static ProfessorVO loginprof;
}
