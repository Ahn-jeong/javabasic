package data;

import vo.StudentVO;

public class StuSession {
	//세션: 인터넷창이 열려있는 동안 유지되는 저장 공간
	
		//로그인 되어있는 유저의 정보를 저장
		public static StudentVO loginstu;
	
}
