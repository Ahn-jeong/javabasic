package vo;

public class SubjectVO {//과목 VO
	private int subNum;//과목번호
	private String subName;//과목명
	
	public int getSubNum() {
		return subNum;
	}
	public void setSubNum(int subNum) {
		this.subNum = subNum;
	}
	public String getSubName() {
		return subName;
	}
	public void setSubName(String subName) {
		this.subName = subName;
	}

}
